#!/usr/bin/env python
import CopyConfigLib as runconfig;

runconfig.connectDb();

