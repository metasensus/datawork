python MachineAdd.py
chmod +x machinestatus.sh
./machinestatus.sh &
python initialbuild_vm.py
