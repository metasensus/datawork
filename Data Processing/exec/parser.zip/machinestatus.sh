python machinestatus.py
