#!/usr/bin/env python
import hostlib as hst;
import oracleconnect as oracon
import mysqlconnect as mconnect;
import time;
import os;
import commands;
import string;
import statslog;
import sys;

p = commands.getoutput("ps -ef | grep [m]achinestatus |wc -l");
constr='ods/ods@callhomeods:1521/callhomeods';

try:
   if int(p) > 0:
      exit();
except:
   while True:
      try:
         #print "Getting host IP....";
         hstip=hst.retHostIP();
         hstname=hst.retHostName();
         #print hstname;
         #lconn = mconnect.connectMysql('ods','procuser','c@llhome','localhost');
         #lcurr = lconn.cursor();
         oraconn=oracon.openconnect(constr);
         #print "Getting purpose of the machine....";
         sqlstmt='select purpose,substr(splitterloc,2,instr(splitterloc,\'/\',1,2)-instr(splitterloc,\'/\',1,1)-1) splitloc,substr(processloc,2,instr(processloc,\'/\',1,2)-instr(processloc,\'/\',1,1)-1)processloc,';
         sqlstmt+='machineid,substr(taggerloc,2,instr(taggerloc,\'/\',1,2)-instr(taggerloc,\'/\',1,1)-1)taggerloc from statsprocessingmachine where ipaddress=\''+hstip+'\'';
         mpurpose=oracon.execSql(oraconn,sqlstmt);
         
         for mp in mpurpose:
            pdatacopy=0;
            pparser=0;
            pcpmeta=0;
            dataloc=0;
            processed=0;
            tobeProcessed=0;
            errored=0;
            p1="dataCopy"
            p2="parse"
            p3="copymeta"
            purpose=mp[0];
            macid=mp[3];
            #print purpose;
         mpurpose.close();
         oraconn.close();
         
         if purpose=='splitter':
            dataloc=mp[1];
            lconn = mconnect.connectMysql('ods','procuser','c@llhome','localhost');
            lcurr = lconn.cursor();
            lcurr.execute('select count(1) from STATS_SPLIT_FILES');
            splitCount=lcurr.fetchall();
            for rec in splitCount:
               recCount=rec[0];
            #print "dataCopy count is:"+str(recCount);
            sqlstmt='select ifnull(file_process_status,0),count(1) from STATSPROCESSTRANSACT group by file_process_status';
            lcurr.execute(sqlstmt);
            processData=lcurr.fetchall();
            for prec in processData:
               if prec[0]==0:
                  tobeProcessed=prec[1];
                  #print "To be Processed Count:"+str(tobeProcessed);
               if prec[0]==1:
                  processed=prec[1];
                  #print "Processed Count:"+str(processed);
               if prec[0]==3:
                  errored=prec[1];
                  #print "Failed Count:"+str(errored);
            lconn.close();
         
         if purpose=='process':
            dataloc=mp[2];
            lconn = mconnect.connectMysql('ods','procuser','c@llhome','localhost');
            lcurr = lconn.cursor();
            lcurr.execute('select count(1) from STATSOUTPUT');
            tabberCount=lcurr.fetchall();
            for rec in tabberCount:
               recCount=rec[0];
            sqlstmt='select ifnull(file_process_status,0),count(1) from STATS_SPLIT_FILES group by ifnull(file_process_status,0)';
            lcurr.execute(sqlstmt);
            processData=lcurr.fetchall();
            for prec in processData:
               if prec[0]==0:
                  tobeProcessed=prec[1];
               if prec[0]==1:
                  processed=prec[1];
               if prec[0]==3:
                  errored=prec[1];
            lconn.close();
         
         if purpose=='tagger':
            recCount=0;
            dataloc=mp[4];

         #print "getting disk utilization....";
         #print dataloc;
         #cstring=("df -k | grep %s|awk '{print $5}'"%dataloc);
         #istring=("df -i | grep %s|awk '{print $5}'"%dataloc);
         #diskutil=commands.getoutput(cstring);
         #inodeutil=commands.getoutput(istring);
         pythonRuns=commands.getoutput("ps -ef|grep [p]ython|wc -l");

         plist = os.popen("ps -Af|grep python").read();

         if p1 in plist[:]:
            pdatacopy=1;
         if p2 in plist[:]:
            pparser=1;
         if p3 in plist[:]:
            pcpmeta=1;

         ##Reading log files for errors
         #logFile=commands.getoutput("ls -t log|head -1");
         #logFile='log/'+logFile;
         #logFileRd=open(logFile, 'r').readlines();

         oraconn=oracon.openconnect(constr);
         sqlst='begin insert into OMI_MACHINE_STATUS (MACHINENAME,IPADDRESS,STATUS_POST_TIME,PURPOSE,NUM_PYTHON_THREADS,DATALOCATION,DATACOPY_STATUS,PARSER_STATUS,COPYMETA_STATUS,PROCESSED,TOBEPROCESSED';
         sqlst+=',TOBECOPIED,FAILEDTOPROCESS) values (\''+str(hstname)+'\',\''+str(hstip)+'\',sysdate,\''+mp[0]+'\',\''+str(pythonRuns)+'\',\''+str(dataloc)+'\',';
         sqlst+='\''+str(pdatacopy)+'\',\''+str(pparser)+'\',\''+str(pcpmeta)+'\','+str(processed)+','+str(tobeProcessed)+','+str(recCount)+','+str(errored)+'); commit; end;';
         oracon.execSql(oraconn,sqlst);
         #print "closing connection";
         oraconn.close();

      except Exception:
         fl=statslog.logcreate("log/machineStatus.log");
         statslog.logwrite(fl,"Error reported: "+str(sys.exc_info()[1]));
      time.sleep(2*900);
